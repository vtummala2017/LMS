"""Whiteboard Simple: a one-file learning management system.
Python + server-rendered pages + PostgreSQL. No Node, no Redis, no build step."""
import os, re, json, hashlib, hmac, secrets, datetime as dt
from fastapi import FastAPI, Depends, Request, Form, UploadFile, File, HTTPException
from fastapi.responses import RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from starlette.concurrency import run_in_threadpool
from sqlalchemy import (create_engine, Column, Integer, String, Text, Float, ForeignKey,
                        DateTime, LargeBinary, UniqueConstraint)
from sqlalchemy.orm import declarative_base, sessionmaker

HERE = os.path.dirname(__file__)
MAX_UPLOAD = 5 * 1024 * 1024  # 5 MB per file, stored in the database

url = os.getenv("DATABASE_URL", "sqlite:///./whiteboard.db")
if url.startswith("postgres://"):
    url = url.replace("postgres://", "postgresql+psycopg2://", 1)
elif url.startswith("postgresql://"):
    url = url.replace("postgresql://", "postgresql+psycopg2://", 1)
kw = ({"connect_args": {"check_same_thread": False}} if url.startswith("sqlite")
      else {"pool_size": 8, "max_overflow": 4, "pool_pre_ping": True, "pool_recycle": 1800})
engine = create_engine(url, **kw)
SessionLocal = sessionmaker(bind=engine, autoflush=False)
Base = declarative_base()
now = lambda: dt.datetime.utcnow()


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    name = Column(String(255), nullable=False)
    pw = Column(String(255), nullable=False)
    role = Column(String(20), default="student")  # student | teacher | admin


class Course(Base):
    __tablename__ = "courses"
    id = Column(Integer, primary_key=True)
    title = Column(String(255), nullable=False)
    description = Column(Text, default="")
    code = Column(String(12), unique=True, index=True)
    teacher_id = Column(Integer, ForeignKey("users.id"), index=True)


class Enrollment(Base):
    __tablename__ = "enrollments"
    __table_args__ = (UniqueConstraint("course_id", "user_id"),)
    id = Column(Integer, primary_key=True)
    course_id = Column(Integer, ForeignKey("courses.id"), index=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True)


class Announcement(Base):
    __tablename__ = "announcements"
    id = Column(Integer, primary_key=True)
    course_id = Column(Integer, ForeignKey("courses.id"), index=True)
    title = Column(String(255))
    body = Column(Text)
    created = Column(DateTime, default=now)


class Assignment(Base):
    __tablename__ = "assignments"
    id = Column(Integer, primary_key=True)
    course_id = Column(Integer, ForeignKey("courses.id"), index=True)
    title = Column(String(255))
    description = Column(Text, default="")
    due = Column(String(20), default="")
    points = Column(Float, default=100)
    kind = Column(String(20), default="assignment")  # assignment | quiz


class Question(Base):
    __tablename__ = "questions"
    id = Column(Integer, primary_key=True)
    assignment_id = Column(Integer, ForeignKey("assignments.id"), index=True)
    text = Column(Text)
    options = Column(Text)  # one option per line
    correct = Column(Integer)  # index of the correct option


class Submission(Base):
    __tablename__ = "submissions"
    __table_args__ = (UniqueConstraint("assignment_id", "student_id"),)
    id = Column(Integer, primary_key=True)
    assignment_id = Column(Integer, ForeignKey("assignments.id"), index=True)
    student_id = Column(Integer, ForeignKey("users.id"), index=True)
    text = Column(Text, default="")
    filename = Column(String(255), default="")
    filedata = Column(LargeBinary, nullable=True)
    submitted = Column(DateTime, default=now)
    grade = Column(Float, nullable=True)
    feedback = Column(Text, default="")
    answers = Column(Text, nullable=True)  # quiz answers as JSON {question_id: option_index}


def init_db():
    from sqlalchemy import inspect, text
    Base.metadata.create_all(engine)
    insp = inspect(engine)  # add new columns to databases created by an older version
    with engine.begin() as cx:
        if "kind" not in [c["name"] for c in insp.get_columns("assignments")]:
            cx.execute(text("ALTER TABLE assignments ADD COLUMN kind VARCHAR(20) DEFAULT 'assignment'"))
        if "answers" not in [c["name"] for c in insp.get_columns("submissions")]:
            cx.execute(text("ALTER TABLE submissions ADD COLUMN answers TEXT"))


app = FastAPI(title="Whiteboard")
app.add_middleware(SessionMiddleware, secret_key=os.getenv("SECRET_KEY", "dev-only-change-me"),
                   same_site="lax", https_only=os.getenv("COOKIE_SECURE", "0") == "1",
                   max_age=60 * 60 * 24 * 14)
app.mount("/static", StaticFiles(directory=os.path.join(HERE, "static")), name="static")
templates = Jinja2Templates(directory=os.path.join(HERE, "templates"))


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


class NeedLogin(Exception):
    pass


@app.exception_handler(NeedLogin)
async def _need_login(request, exc):
    return RedirectResponse("/login", 303)


def current_user(request: Request, db=Depends(get_db)):
    uid = request.session.get("uid")
    u = db.get(User, uid) if uid else None
    if not u:
        raise NeedLogin()
    return u


def hash_pw(pw, salt=None):
    salt = salt or secrets.token_hex(16)
    return salt + "$" + hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 200_000).hex()


def check_pw(pw, stored):
    salt, _ = stored.split("$")
    return hmac.compare_digest(hash_pw(pw, salt), stored)


def page(request, name, user=None, **ctx):
    return templates.TemplateResponse(request, name, {"user": user, **ctx})


def course_access(db, user, cid):
    c = db.get(Course, cid)
    if not c:
        raise HTTPException(404, "Course not found")
    is_teacher = user.role == "admin" or c.teacher_id == user.id
    if not is_teacher and not db.query(Enrollment).filter_by(course_id=cid, user_id=user.id).first():
        raise HTTPException(403, "You are not enrolled in this course")
    return c, is_teacher


def need_teacher(user):
    if user.role not in ("teacher", "admin"):
        raise HTTPException(403, "Teachers only")


@app.get("/health")
def health():
    return {"ok": True}


# ---------- accounts ----------
@app.get("/login")
def login_form(request: Request):
    return page(request, "login.html", error=request.query_params.get("error"))


@app.post("/login")
def login(request: Request, email: str = Form(...), password: str = Form(...), db=Depends(get_db)):
    u = db.query(User).filter_by(email=email.strip().lower()).first()
    if not u or not check_pw(password, u.pw):
        return RedirectResponse("/login?error=Wrong+email+or+password", 303)
    request.session["uid"] = u.id
    return RedirectResponse("/", 303)


@app.get("/register")
def register_form(request: Request):
    return page(request, "register.html", error=request.query_params.get("error"))


@app.post("/register")
def register(request: Request, name: str = Form(...), email: str = Form(...),
             password: str = Form(...), db=Depends(get_db)):
    email = email.strip().lower()
    if len(password) < 8:
        return RedirectResponse("/register?error=Password+must+be+at+least+8+characters", 303)
    if db.query(User).filter_by(email=email).first():
        return RedirectResponse("/register?error=That+email+is+already+registered", 303)
    first = db.query(User).count() == 0  # the very first account becomes the admin
    u = User(email=email, name=name.strip(), pw=hash_pw(password), role="admin" if first else "student")
    db.add(u); db.commit()
    request.session["uid"] = u.id
    return RedirectResponse("/", 303)


@app.get("/logout")
def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/login", 303)


# ---------- dashboard & courses ----------
@app.get("/")
def dashboard(request: Request, user=Depends(current_user), db=Depends(get_db)):
    if user.role in ("teacher", "admin"):
        courses = db.query(Course).filter_by(teacher_id=user.id).all()
    else:
        courses = (db.query(Course).join(Enrollment, Enrollment.course_id == Course.id)
                   .filter(Enrollment.user_id == user.id).all())
    return page(request, "dashboard.html", user, courses=courses, error=request.query_params.get("error"))


@app.post("/courses")
def create_course(title: str = Form(...), description: str = Form(""),
                  user=Depends(current_user), db=Depends(get_db)):
    need_teacher(user)
    c = Course(title=title.strip(), description=description, teacher_id=user.id,
               code=secrets.token_hex(3).upper())
    db.add(c); db.commit()
    return RedirectResponse(f"/courses/{c.id}", 303)


@app.post("/join")
def join(code: str = Form(...), user=Depends(current_user), db=Depends(get_db)):
    c = db.query(Course).filter_by(code=code.strip().upper()).first()
    if not c:
        return RedirectResponse("/?error=Course+code+not+found", 303)
    if not db.query(Enrollment).filter_by(course_id=c.id, user_id=user.id).first():
        db.add(Enrollment(course_id=c.id, user_id=user.id)); db.commit()
    return RedirectResponse(f"/courses/{c.id}", 303)


@app.get("/courses/{cid}")
def course_page(cid: int, request: Request, user=Depends(current_user), db=Depends(get_db)):
    c, is_teacher = course_access(db, user, cid)
    anns = db.query(Announcement).filter_by(course_id=cid).order_by(Announcement.created.desc()).limit(50).all()
    assigns = db.query(Assignment).filter_by(course_id=cid).order_by(Assignment.id.desc()).all()
    people = []
    if is_teacher:
        people = (db.query(User).join(Enrollment, Enrollment.user_id == User.id)
                  .filter(Enrollment.course_id == cid).order_by(User.name).all())
    return page(request, "course.html", user, c=c, is_teacher=is_teacher, anns=anns,
                assigns=assigns, people=people, error=request.query_params.get("error"))


@app.post("/courses/{cid}/announce")
def announce(cid: int, title: str = Form(...), body: str = Form(""),
             user=Depends(current_user), db=Depends(get_db)):
    c, t = course_access(db, user, cid)
    if not t: raise HTTPException(403)
    db.add(Announcement(course_id=cid, title=title, body=body)); db.commit()
    return RedirectResponse(f"/courses/{cid}", 303)


@app.post("/courses/{cid}/assignments")
def new_assignment(cid: int, title: str = Form(...), description: str = Form(""),
                   due: str = Form(""), points: float = Form(100),
                   user=Depends(current_user), db=Depends(get_db)):
    c, t = course_access(db, user, cid)
    if not t: raise HTTPException(403)
    db.add(Assignment(course_id=cid, title=title, description=description, due=due, points=points))
    db.commit()
    return RedirectResponse(f"/courses/{cid}", 303)


def parse_quiz(raw):
    """Blocks separated by a blank line. Line 1 = question, next lines = options, correct option starts with *."""
    out = []
    for n, block in enumerate(re.split(r"\n\s*\n", raw.replace("\r", "").strip()), 1):
        lines = [l.strip() for l in block.split("\n") if l.strip()]
        if len(lines) < 3:
            raise ValueError(f"Question {n} needs a question line and at least 2 options")
        text, opts = lines[0], lines[1:]
        right = [i for i, o in enumerate(opts) if o.startswith("*")]
        if len(right) != 1:
            raise ValueError(f"Question {n} must have exactly one correct option marked with *")
        out.append((text, [o.lstrip("*").strip() for o in opts], right[0]))
    return out


@app.post("/courses/{cid}/quizzes")
def new_quiz(cid: int, title: str = Form(...), due: str = Form(""), points: float = Form(100),
             questions: str = Form(...), user=Depends(current_user), db=Depends(get_db)):
    c, t = course_access(db, user, cid)
    if not t: raise HTTPException(403)
    try:
        parsed = parse_quiz(questions)
    except ValueError as e:
        return RedirectResponse(f"/courses/{cid}?error={str(e).replace(' ', '+')}", 303)
    a = Assignment(course_id=cid, title=title, due=due, points=points, kind="quiz", description="")
    db.add(a); db.flush()
    for text, opts, right in parsed:
        db.add(Question(assignment_id=a.id, text=text, options="\n".join(opts), correct=right))
    db.commit()
    return RedirectResponse(f"/assignments/{a.id}", 303)


# ---------- assignments, submissions, grading ----------
@app.get("/assignments/{aid}")
def assignment_page(aid: int, request: Request, user=Depends(current_user), db=Depends(get_db)):
    a = db.get(Assignment, aid)
    if not a: raise HTTPException(404)
    c, is_teacher = course_access(db, user, a.course_id)
    items = []
    if a.kind == "quiz":
        qs = db.query(Question).filter_by(assignment_id=aid).order_by(Question.id).all()
        items = [{"q": q, "opts": q.options.split("\n")} for q in qs]
    if is_teacher:
        students = (db.query(User).join(Enrollment, Enrollment.user_id == User.id)
                    .filter(Enrollment.course_id == c.id).order_by(User.name).all())
        subs = {s.student_id: s for s in db.query(Submission).filter_by(assignment_id=aid).all()}
        rows = [(s, subs.get(s.id)) for s in students]
        return page(request, "assignment.html", user, a=a, c=c, is_teacher=True, rows=rows, items=items)
    sub = db.query(Submission).filter_by(assignment_id=aid, student_id=user.id).first()
    if items and sub:  # after the attempt: show what the student chose
        chosen = json.loads(sub.answers or "{}")
        for it in items:
            it["chosen"] = chosen.get(str(it["q"].id))
    return page(request, "assignment.html", user, a=a, c=c, is_teacher=False, sub=sub, items=items,
                error=request.query_params.get("error"))


@app.post("/assignments/{aid}/submit")
def submit(aid: int, text: str = Form(""), file: UploadFile = File(None),
           user=Depends(current_user), db=Depends(get_db)):
    a = db.get(Assignment, aid)
    if not a: raise HTTPException(404)
    c, is_teacher = course_access(db, user, a.course_id)
    if is_teacher: raise HTTPException(403, "Teachers do not submit")
    if a.kind == "quiz": raise HTTPException(400, "Use the quiz form")
    data, fname = None, ""
    if file is not None and file.filename:
        data = file.file.read(MAX_UPLOAD + 1)
        if len(data) > MAX_UPLOAD:
            return RedirectResponse(f"/assignments/{aid}?error=File+is+larger+than+5+MB", 303)
        fname = os.path.basename(file.filename)[:200]
    s = db.query(Submission).filter_by(assignment_id=aid, student_id=user.id).first()
    if not s:
        s = Submission(assignment_id=aid, student_id=user.id); db.add(s)
    s.text, s.submitted = text, now()
    if data is not None:
        s.filename, s.filedata = fname, data
    db.commit()
    return RedirectResponse(f"/assignments/{aid}", 303)


def _grade_quiz(db, user, aid, chosen):
    a = db.get(Assignment, aid)
    if not a or a.kind != "quiz": raise HTTPException(404)
    c, is_teacher = course_access(db, user, a.course_id)
    if is_teacher: raise HTTPException(403, "Teachers do not take quizzes")
    if db.query(Submission).filter_by(assignment_id=aid, student_id=user.id).first():
        return RedirectResponse(f"/assignments/{aid}", 303)  # one attempt only
    qs = db.query(Question).filter_by(assignment_id=aid).all()
    right = sum(1 for q in qs if chosen.get(str(q.id)) == q.correct)
    score = round(right * a.points / len(qs), 2) if qs else 0
    db.add(Submission(assignment_id=aid, student_id=user.id, answers=json.dumps(chosen), grade=score,
                      feedback=f"Auto-graded: {right}/{len(qs)} correct"))
    db.commit()
    return RedirectResponse(f"/assignments/{aid}", 303)


@app.post("/quizzes/{aid}/take")
async def take_quiz(aid: int, request: Request, user=Depends(current_user), db=Depends(get_db)):
    form = await request.form()
    chosen = {k[1:]: int(v) for k, v in form.items() if k.startswith("q") and str(v).isdigit()}
    return await run_in_threadpool(_grade_quiz, db, user, aid, chosen)


@app.post("/assignments/{aid}/grade/{sid}")
def grade(aid: int, sid: int, grade: float = Form(...), feedback: str = Form(""),
          user=Depends(current_user), db=Depends(get_db)):
    a = db.get(Assignment, aid)
    if not a: raise HTTPException(404)
    c, t = course_access(db, user, a.course_id)
    if not t: raise HTTPException(403)
    s = db.query(Submission).filter_by(assignment_id=aid, student_id=sid).first()
    if not s: raise HTTPException(404, "No submission yet")
    s.grade, s.feedback = grade, feedback
    db.commit()
    return RedirectResponse(f"/assignments/{aid}", 303)


@app.get("/submissions/{sub_id}/file")
def download(sub_id: int, user=Depends(current_user), db=Depends(get_db)):
    s = db.get(Submission, sub_id)
    if not s or not s.filedata: raise HTTPException(404)
    a = db.get(Assignment, s.assignment_id)
    c, t = course_access(db, user, a.course_id)
    if not t and s.student_id != user.id: raise HTTPException(403)
    name = s.filename.replace('"', "")
    return Response(s.filedata, media_type="application/octet-stream",
                    headers={"Content-Disposition": f'attachment; filename="{name}"'})


@app.get("/courses/{cid}/grades")
def gradebook(cid: int, request: Request, user=Depends(current_user), db=Depends(get_db)):
    c, is_teacher = course_access(db, user, cid)
    assigns = db.query(Assignment).filter_by(course_id=cid).order_by(Assignment.id).all()
    ids = [a.id for a in assigns]
    q = db.query(User).join(Enrollment, Enrollment.user_id == User.id).filter(Enrollment.course_id == cid)
    students = q.order_by(User.name).all() if is_teacher else [user]
    subs = {}
    if ids:
        for s in db.query(Submission).filter(Submission.assignment_id.in_(ids),
                                            Submission.student_id.in_([u.id for u in students])).all():
            subs[(s.student_id, s.assignment_id)] = s
    rows = []
    total = sum(a.points for a in assigns) or 1
    for st in students:
        cells = [subs.get((st.id, a.id)) for a in assigns]
        earned = sum(s.grade for s in cells if s and s.grade is not None)
        graded_pts = sum(a.points for a, s in zip(assigns, cells) if s and s.grade is not None)
        pct = round(100 * earned / graded_pts, 1) if graded_pts else None
        rows.append((st, cells, pct))
    return page(request, "grades.html", user, c=c, assigns=assigns, rows=rows, is_teacher=is_teacher)


# ---------- admin ----------
@app.get("/admin")
def admin(request: Request, q: str = "", user=Depends(current_user), db=Depends(get_db)):
    if user.role != "admin": raise HTTPException(403)
    query = db.query(User)
    if q:
        query = query.filter((User.email.ilike(f"%{q}%")) | (User.name.ilike(f"%{q}%")))
    return page(request, "admin.html", user, users=query.order_by(User.id.desc()).limit(200).all(),
                total=db.query(User).count(), courses=db.query(Course).count(), q=q)


@app.post("/admin/users/{uid}/role")
def set_role(uid: int, role: str = Form(...), user=Depends(current_user), db=Depends(get_db)):
    if user.role != "admin": raise HTTPException(403)
    if role not in ("student", "teacher", "admin"): raise HTTPException(400)
    u = db.get(User, uid)
    if u and u.id != user.id:
        u.role = role; db.commit()
    return RedirectResponse("/admin", 303)
